package module1;

/**
 * Created by tim on 01/05/15.
 */
public class HelloWorld {

    public String hello() {
        return "Hello";
    }

    public void notCovered() {
        System.out.println("YOLO");
    }

}
