package module2

class HelloScala2 {

  case class TryOut(some: String, fields: List[String])

  def test = "Hello"

  def someOther = 42
}