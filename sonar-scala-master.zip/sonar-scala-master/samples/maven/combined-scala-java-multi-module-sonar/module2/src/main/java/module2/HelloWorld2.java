package module2;

/**
 * Created by tim on 01/05/15.
 */
public class HelloWorld2 {

    public String hello() {
        return "Hello";
    }

    public void notCovered() {
        System.out.println("YOLO");
    }

}
