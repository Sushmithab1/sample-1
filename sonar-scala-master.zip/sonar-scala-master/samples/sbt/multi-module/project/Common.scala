import sbt._

object Common {
  val baseName = "multi-module"
  val scalatest = "org.scalatest" % "scalatest_2.11" % "2.2.4"
}