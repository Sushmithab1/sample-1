import sbt._
object MyBuild extends com.typesafe.sbt.pom.PomBuild
