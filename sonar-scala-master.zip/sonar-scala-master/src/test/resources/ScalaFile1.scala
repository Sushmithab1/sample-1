class ScalaFile1 {
  val value = "value"

  def function: Unit = {
    println("function called.")
  }
}
